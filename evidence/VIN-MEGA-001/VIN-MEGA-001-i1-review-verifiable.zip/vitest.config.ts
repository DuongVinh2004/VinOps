import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vitest/config';

const root = fileURLToPath(new URL('.', import.meta.url));

export default defineConfig({
  resolve: {
    alias: {
      '@vinops/config': `${root}packages/config/src/index.ts`,
      '@vinops/contracts': `${root}packages/contracts/src/index.ts`,
      '@vinops/database': `${root}packages/database/src/index.ts`,
      '@vinops/domain': `${root}packages/domain/src/index.ts`,
      '@vinops/observability': `${root}packages/observability/src/index.ts`,
    },
  },
  test: {
    include: ['apps/*/test/**/*.test.{ts,tsx}', 'packages/*/test/**/*.test.ts'],
    setupFiles: ['apps/web/test/setup.ts'],
    testTimeout: 15_000,
  },
});
