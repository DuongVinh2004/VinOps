export type ApiSession = {
  accessToken: string;
  accessTokenExpiresAt: string;
  csrfToken: string;
  sessionId: string;
  user: {
    id: string;
    displayName: string;
  };
};

export type Organization = {
  id: string;
  code: string;
  name: string;
  status: string;
  version: string;
};

export type Project = {
  id: string;
  organizationId: string;
  code: string;
  name: string;
  timezone: string;
  status: string;
  version: string;
};

export type ProjectMember = {
  id: string;
  displayName: string;
  roles: readonly string[];
  status: string;
  version: string;
};

export type ContextEntity = {
  id: string;
  code?: string;
  name: string;
  parentId?: string;
  status: string;
};

export type ProjectContext = {
  calendars: readonly ContextEntity[];
  classifications: readonly ContextEntity[];
  disciplines: readonly ContextEntity[];
  locationNodes: readonly ContextEntity[];
  numberingProfiles: readonly ContextEntity[];
  partners: readonly ContextEntity[];
  workNodes: readonly ContextEntity[];
};

type Fetcher = typeof fetch;
type JsonRecord = Record<string, unknown>;

export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    readonly retryable: boolean,
  ) {
    super(code);
    this.name = 'ApiError';
  }
}

function isRecord(value: unknown): value is JsonRecord {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function requiredString(value: unknown, field: string): string {
  if (typeof value !== 'string' || value.length === 0) {
    throw new ApiError(502, `INVALID_API_RESPONSE_${field.toUpperCase()}`, false);
  }
  return value;
}

function optionalString(value: unknown): string | undefined {
  return typeof value === 'string' && value.length > 0 ? value : undefined;
}

function stringArray(value: unknown): readonly string[] {
  return Array.isArray(value)
    ? value.filter((item): item is string => typeof item === 'string')
    : [];
}

function asRecord(value: unknown): JsonRecord {
  if (!isRecord(value)) {
    throw new ApiError(502, 'INVALID_API_RESPONSE', false);
  }
  return value;
}

function toOrganization(value: unknown): Organization {
  const record = asRecord(value);
  return {
    id: requiredString(record.id, 'organization_id'),
    code: requiredString(record.code, 'organization_code'),
    name: requiredString(record.name, 'organization_name'),
    status: requiredString(record.status, 'organization_status'),
    version: requiredString(record.version, 'organization_version'),
  };
}

function toProject(value: unknown): Project {
  const record = asRecord(value);
  return {
    id: requiredString(record.id, 'project_id'),
    organizationId: requiredString(record.organization_id, 'project_organization_id'),
    code: requiredString(record.code, 'project_code'),
    name: requiredString(record.name, 'project_name'),
    timezone: requiredString(record.timezone, 'project_timezone'),
    status: requiredString(record.status, 'project_status'),
    version: requiredString(record.version, 'project_version'),
  };
}

function toMember(value: unknown): ProjectMember {
  const record = asRecord(value);
  return {
    id: requiredString(record.id, 'membership_id'),
    displayName: requiredString(record.display_name, 'membership_display_name'),
    roles: stringArray(record.roles),
    status: requiredString(record.status, 'membership_status'),
    version: requiredString(record.version, 'membership_version'),
  };
}

function toContextEntity(value: unknown): ContextEntity {
  const record = asRecord(value);
  const code = optionalString(record.code);
  const parentId = optionalString(record.parent_id);
  return {
    id: requiredString(record.id, 'context_id'),
    name: requiredString(record.name, 'context_name'),
    status: requiredString(record.status, 'context_status'),
    ...(code === undefined ? {} : { code }),
    ...(parentId === undefined ? {} : { parentId }),
  };
}

function pageItems(value: unknown): readonly unknown[] {
  const page = asRecord(value);
  return Array.isArray(page.items) ? page.items : [];
}

function sessionFromResponse(value: unknown): ApiSession {
  const record = asRecord(value);
  const user = asRecord(record.user);
  return {
    accessToken: requiredString(record.access_token, 'access_token'),
    accessTokenExpiresAt: requiredString(record.access_token_expires_at, 'access_token_expires_at'),
    csrfToken: requiredString(record.csrf_token, 'csrf_token'),
    sessionId: requiredString(record.session_id, 'session_id'),
    user: {
      id: requiredString(user.id, 'user_id'),
      displayName: requiredString(user.display_name, 'user_display_name'),
    },
  };
}

function contextItems(value: unknown, field: string): readonly ContextEntity[] {
  const record = asRecord(value);
  const items = record[field];
  return Array.isArray(items) ? items.map(toContextEntity) : [];
}

function createUrl(baseUrl: string, path: string): string {
  return `${baseUrl.replace(/\/$/u, '')}/${path.replace(/^\//u, '')}`;
}

function createIdempotencyKey(): string {
  const uuid = globalThis.crypto?.randomUUID?.();
  return uuid === undefined
    ? `web-${Date.now()}-${Math.random().toString(36).slice(2)}`
    : `web-${uuid}`;
}

type RequestOptions = {
  authenticated?: boolean;
  retryOnUnauthorized?: boolean;
};

/**
 * Browser-only API boundary. The refresh token is never exposed here: fetch sends the
 * HttpOnly cookie with `credentials: include`, while access and CSRF tokens remain in this object.
 */
export class VinopsApiClient {
  private session: ApiSession | null = null;
  private refreshInFlight: Promise<ApiSession> | null = null;

  constructor(
    private readonly baseUrl: string,
    private readonly fetcher: Fetcher = globalThis.fetch.bind(globalThis),
  ) {}

  getSession(): ApiSession | null {
    return this.session;
  }

  setSession(session: ApiSession | null): void {
    this.session = session;
  }

  async login(email: string, password: string): Promise<ApiSession> {
    const response = await this.request<unknown>(
      'auth/sessions',
      {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ email, password, device_name: 'vinops-web' }),
      },
      { authenticated: false, retryOnUnauthorized: false },
    );
    this.session = sessionFromResponse(response);
    return this.session;
  }

  async refresh(): Promise<ApiSession> {
    if (this.refreshInFlight !== null) {
      return this.refreshInFlight;
    }
    const refresh = this.performRefresh();
    this.refreshInFlight = refresh;
    try {
      return await refresh;
    } finally {
      if (this.refreshInFlight === refresh) {
        this.refreshInFlight = null;
      }
    }
  }

  private async performRefresh(): Promise<ApiSession> {
    const csrfToken = this.session?.csrfToken;
    if (csrfToken === undefined) {
      throw new ApiError(401, 'REFRESH_CONTEXT_MISSING', false);
    }
    const response = await this.request<unknown>(
      'auth/refresh',
      { method: 'POST', headers: { 'x-csrf-token': csrfToken } },
      { authenticated: false, retryOnUnauthorized: false },
    );
    this.session = sessionFromResponse(response);
    return this.session;
  }

  async signOut(): Promise<void> {
    try {
      await this.request<void>(
        'auth/sessions',
        { method: 'DELETE' },
        { retryOnUnauthorized: false },
      );
    } finally {
      this.session = null;
    }
  }

  async listOrganizations(): Promise<readonly Organization[]> {
    return this.organizationsFromResponse(await this.request<unknown>('organizations'));
  }

  async listProjects(organizationId: string): Promise<readonly Project[]> {
    const response = await this.request<unknown>(
      `organizations/${encodeURIComponent(organizationId)}/projects`,
    );
    return pageItems(response).map(toProject);
  }

  async getProject(projectId: string): Promise<Project> {
    return toProject(await this.request<unknown>(`projects/${encodeURIComponent(projectId)}`));
  }

  async listMembers(projectId: string): Promise<readonly ProjectMember[]> {
    const response = await this.request<unknown>(
      `projects/${encodeURIComponent(projectId)}/members`,
    );
    return pageItems(response).map(toMember);
  }

  async getProjectContext(projectId: string): Promise<ProjectContext> {
    const response = await this.request<unknown>(
      `projects/${encodeURIComponent(projectId)}/context`,
    );
    return {
      calendars: contextItems(response, 'calendars'),
      classifications: contextItems(response, 'classifications'),
      disciplines: contextItems(response, 'disciplines'),
      locationNodes: contextItems(response, 'location_nodes'),
      numberingProfiles: contextItems(response, 'numbering_profiles'),
      partners: contextItems(response, 'partners'),
      workNodes: contextItems(response, 'work_nodes'),
    };
  }

  async createInvitation(input: {
    projectId: string;
    email: string;
    roles: readonly string[];
    scopes: readonly Record<string, unknown>[];
    validTo: string;
  }): Promise<void> {
    await this.request<unknown>(`projects/${encodeURIComponent(input.projectId)}/invitations`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'idempotency-key': createIdempotencyKey(),
      },
      body: JSON.stringify({
        email: input.email,
        roles: input.roles,
        scopes: input.scopes,
        valid_to: input.validTo,
      }),
    });
  }

  private organizationsFromResponse(value: unknown): readonly Organization[] {
    return pageItems(value).map(toOrganization);
  }

  private async request<T>(
    path: string,
    init: RequestInit = {},
    options: RequestOptions = {},
  ): Promise<T> {
    const authenticated = options.authenticated ?? true;
    const retryOnUnauthorized = options.retryOnUnauthorized ?? authenticated;
    const response = await this.send(path, init, authenticated);
    if (response.status === 401 && retryOnUnauthorized && this.session !== null) {
      try {
        await this.refresh();
      } catch {
        this.session = null;
        throw await this.toApiError(response);
      }
      return this.request<T>(path, init, { authenticated, retryOnUnauthorized: false });
    }
    if (!response.ok) {
      throw await this.toApiError(response);
    }
    if (response.status === 204) {
      return undefined as T;
    }
    return (await response.json()) as T;
  }

  private async send(path: string, init: RequestInit, authenticated: boolean): Promise<Response> {
    const headers = new Headers(init.headers);
    headers.set('accept', 'application/json');
    if (authenticated && this.session !== null) {
      headers.set('authorization', `Bearer ${this.session.accessToken}`);
    }
    return this.fetcher(createUrl(this.baseUrl, path), {
      ...init,
      headers,
      credentials: 'include',
    });
  }

  private async toApiError(response: Response): Promise<ApiError> {
    let body: unknown;
    try {
      body = await response.json();
    } catch {
      body = undefined;
    }
    const record = isRecord(body) ? body : {};
    return new ApiError(
      response.status,
      typeof record.code === 'string' ? record.code : `HTTP_${response.status}`,
      record.retryable === true,
    );
  }
}
