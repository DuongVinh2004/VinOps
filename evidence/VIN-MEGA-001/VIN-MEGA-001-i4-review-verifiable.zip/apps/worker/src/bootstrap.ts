import { ShutdownSignal, type INestApplicationContext } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { loadWorkerConfig, type WorkerConfig } from '@vinops/config';
import { VinopsDatabase } from '@vinops/database';
import { createLogger } from '@vinops/observability';
import { NestStructuredLogger } from './nest-logger.js';
import { createOutboxPoller, type OutboxPoller } from './outbox-poller.js';
import { DeterministicInProcessPublisher } from './outbox-publisher.js';
import { OutboxWorker } from './outbox-worker.js';
import { PostgreSqlOutboxStore } from './postgres-outbox-store.js';
import { WorkerLifecycle } from './worker-lifecycle.js';
import { WorkerModule } from './worker.module.js';

export type WorkerApplication = {
  app: INestApplicationContext;
  config: WorkerConfig;
  lifecycle: WorkerLifecycle;
  outboxEnabled: boolean;
  shutdown: () => Promise<void>;
};

export function enableWorkerGracefulShutdown(
  application: Pick<INestApplicationContext, 'enableShutdownHooks'>,
): void {
  application.enableShutdownHooks([ShutdownSignal.SIGINT, ShutdownSignal.SIGTERM]);
}

function databaseUrl(environment: NodeJS.ProcessEnv): string | undefined {
  const value = environment.VINOPS_DATABASE_URL?.trim();
  return value === undefined || value.length === 0 ? undefined : value;
}

function pollIntervalMs(environment: NodeJS.ProcessEnv): number {
  const raw = environment.VINOPS_OUTBOX_POLL_INTERVAL_MS;
  if (raw === undefined || !/^\d+$/u.test(raw)) {
    return 1_000;
  }
  return Math.max(250, Math.min(Number(raw), 60_000));
}

function createOptionalOutboxRuntime(
  environment: NodeJS.ProcessEnv,
  workerName: string,
  logger: ReturnType<typeof createLogger>,
): { database: VinopsDatabase; poller: OutboxPoller } | undefined {
  const connectionString = databaseUrl(environment);
  if (connectionString === undefined) {
    return undefined;
  }

  const database = new VinopsDatabase({
    connectionString,
    applicationName: `vinops-outbox-worker:${workerName}`,
    runtimeRole: 'vinops_worker',
  });
  const worker = new OutboxWorker(
    new PostgreSqlOutboxStore(database),
    new DeterministicInProcessPublisher(),
    logger,
    { workerName },
  );
  return {
    database,
    poller: createOutboxPoller(worker, logger, pollIntervalMs(environment)),
  };
}

export async function createWorkerApplication(
  environment: NodeJS.ProcessEnv = process.env,
): Promise<WorkerApplication> {
  const config = loadWorkerConfig(environment);
  const logger = createLogger('vinops-worker', config.VINOPS_LOG_LEVEL);
  const app = await NestFactory.createApplicationContext(WorkerModule, {
    bufferLogs: false,
    logger: new NestStructuredLogger(logger),
  });
  enableWorkerGracefulShutdown(app);

  const lifecycle = app.get(WorkerLifecycle);
  const outboxRuntime = createOptionalOutboxRuntime(environment, config.VINOPS_WORKER_NAME, logger);
  outboxRuntime?.poller.start();
  logger.info({ worker_name: config.VINOPS_WORKER_NAME }, 'worker application context started');
  if (outboxRuntime === undefined) {
    logger.info(
      { worker_name: config.VINOPS_WORKER_NAME },
      'outbox runtime disabled because VINOPS_DATABASE_URL is not configured',
    );
  } else {
    logger.info(
      { worker_name: config.VINOPS_WORKER_NAME },
      'outbox runtime enabled using dedicated database worker role',
    );
  }

  return {
    app,
    config,
    lifecycle,
    outboxEnabled: outboxRuntime !== undefined,
    shutdown: async () => {
      logger.info(
        { worker_name: config.VINOPS_WORKER_NAME },
        'worker application context stopping',
      );
      await outboxRuntime?.poller.stop();
      await outboxRuntime?.database.close();
      await app.close();
    },
  };
}
